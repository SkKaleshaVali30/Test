﻿from flask import Flask, request, jsonify, render_template
import sqlite3
import openai
import os
import re
from collections import deque, defaultdict

app = Flask(__name__, template_folder="frontend")

# --- OpenAI API key ---
openai.api_key = "OpenAI_API_Key_Here"
# --- Database ---
DB_FILE = os.path.abspath("bank.db")
print("📂 Using DB file:", DB_FILE)

# --- Load schema ---
def load_schema():
    schema = {}
    primary_keys = {}
    foreign_keys = defaultdict(list)
    try:
        with sqlite3.connect(DB_FILE) as conn:
            cur = conn.cursor()
            tables = cur.execute(
                "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%';"
            ).fetchall()
            for (table,) in tables:
                cols = cur.execute(f"PRAGMA table_info({table});").fetchall()
                schema[table] = [col[1] for col in cols]
                for col in cols:
                    if col[5]:  # PK
                        primary_keys[table] = col[1]
                fks = cur.execute(f"PRAGMA foreign_key_list({table});").fetchall()
                for fk in fks:
                    foreign_keys[table].append((fk[3], fk[2], fk[4]))  # col_from, table_to, col_to
    except sqlite3.Error as e:
        print(f"Database error: {e}")
        return {}, {}, defaultdict(list)
    return schema, primary_keys, foreign_keys

SCHEMA, PRIMARY_KEYS, FOREIGN_KEYS = load_schema()

# --- Build join graph ---
JOIN_GRAPH = defaultdict(list)
for table, fks in FOREIGN_KEYS.items():
    for col_from, table_to, col_to in fks:
        JOIN_GRAPH[table].append((table_to, col_from, col_to))
        JOIN_GRAPH[table_to].append((table, col_from, col_to))

# --- BFS join path ---
def find_join_path(start_tables, target_table):
    queue = deque([(t, []) for t in start_tables])
    visited = set(start_tables)
    while queue:
        current, path = queue.popleft()
        if current == target_table:
            return path
        for neighbor, col_from, col_to in JOIN_GRAPH.get(current, []):
            if neighbor not in visited:
                visited.add(neighbor)
                queue.append((neighbor, path + [(current, neighbor, col_from, col_to)]))
    return []

# --- Generate joins with aliases ---
def generate_joins(path, alias_map, used_aliases, inner_tables=set()):
    joins_sql = []
    for left, right, left_col, right_col in path:
        left_alias = next(a for a, t in alias_map.items() if t == left)
        right_alias = next((a for a, t in alias_map.items() if t == right), None)
        if not right_alias:
            base_alias = right[:2].lower()
            right_alias = base_alias
            count = 1
            while right_alias in used_aliases:
                right_alias = f"{base_alias}{count}"
                count += 1
            alias_map[right_alias] = right
            used_aliases.add(right_alias)
        join_type = "INNER JOIN" if right in inner_tables else "LEFT JOIN"
        joins_sql.append(f"{join_type} {right} {right_alias} ON {left_alias}.{left_col} = {right_alias}.{right_col}")
    return joins_sql

# --- Run SQL ---
def run_sql(query):
    try:
        with sqlite3.connect(DB_FILE) as conn:
            cur = conn.cursor()
            cur.execute(query)
            rows = cur.fetchall()
            cols = [desc[0] for desc in cur.description] if cur.description else []
            return {"success": True, "columns": cols, "rows": rows}
    except Exception as e:
        return {"success": False, "error": str(e)}

# --- Build SQL dynamically ---
def build_sql(nlq):
    nlq_lower = nlq.lower()
    is_count_query = bool(re.search(r'\b(count|number of|total|how many)\b', nlq_lower))
    is_unique_query = 'unique' in nlq_lower
    group_by_cols = []
    
    # 1. Handle GROUP BY clauses first and remove from the query string
    group_by_col = None
    group_by_match = re.search(r'\b(?:group by|per)\s+(\w+)\b', nlq_lower)
    if group_by_match:
        group_by_col = group_by_match.group(1)
        nlq = re.sub(r'\b(?:group by|per)\s+\w+\b', '', nlq, flags=re.IGNORECASE).strip()
        nlq_lower = nlq.lower()

    # 2. Handle ORDER BY / sorting logic and remove from the query string
    order_by_col = None
    order_by_dir = None
    order_by_pattern = r'\b(?:sort by|order by|sorted by|highest|lowest|most|least)\s+(\w+)\s*(?:asc|desc)?\b'
    order_by_match = re.search(order_by_pattern, nlq_lower)
    if order_by_match:
        order_by_col = order_by_match.group(1)
        direction_match = re.search(r'\b(asc|desc)\b', nlq_lower)
        if direction_match:
            order_by_dir = direction_match.group(1).upper()
        else:
            if re.search(r'\b(?:highest|most)\b', nlq_lower):
                order_by_dir = 'DESC'
            elif re.search(r'\b(?:lowest|least)\b', nlq_lower):
                order_by_dir = 'ASC'
            else:
                order_by_dir = 'DESC'
        nlq = re.sub(order_by_pattern, '', nlq, flags=re.IGNORECASE).strip()
        nlq_lower = nlq.lower()

    # 3. Handle LIMIT after extracting order by
    limit_match = re.search(r'\b(?:show|top)\s+(\d+)\b', nlq_lower)
    limit_number = int(limit_match.group(1)) if limit_match else None
    
    # --- Detect aggregate functions and columns ---
    aggregates = {
        'sum': 'SUM', 'total': 'SUM',
        'average': 'AVG', 'avg': 'AVG',
        'max': 'MAX', 'maximum': 'MAX',
        'min': 'MIN', 'minimum': 'MIN',
    }
    agg_func = None
    agg_col = None
    
    for keyword, sql_func in aggregates.items():
        for table_name, columns in SCHEMA.items():
            for column in columns:
                pattern = rf'\b{keyword}\b(?:(?:\s+of)?\s+(\w+)\s+)?\b{column}\b'
                if re.search(pattern, nlq_lower):
                    agg_func = sql_func
                    agg_col = column
                    break
            if agg_col:
                break
        if agg_col:
            break
            
    # --- Detect all needed columns & conditions ---
    mentioned_columns = set()
    all_conditions = []
    
    # Add the GROUP BY and ORDER BY columns to mentioned_columns
    if group_by_col:
        mentioned_columns.add(group_by_col)
    if order_by_col:
        mentioned_columns.add(order_by_col)

    # Find columns explicitly mentioned in the query
    for table, columns in SCHEMA.items():
        for col in columns:
            if re.search(rf'\b{col}\b', nlq_lower):
                mentioned_columns.add(col)

    # Dynamically add all columns for "details" keywords
    for table_name in SCHEMA:
        if re.search(rf'{table_name} details|{table_name}s details|all {table_name}s', nlq_lower):
            for col in SCHEMA.get(table_name, []):
                mentioned_columns.add(col)
            
    # Find equality and numeric conditions from the cleaned string
    equality_pattern = r"(\w+)\s+(?:is|equals|=)\s*['\"\[]?([^'\"\]]+)['\"\]]?"
    numeric_keywords = {'greater than': '>', 'less than': '<', 'more than': '>', 'over': '>', 'under': '<'}
    
    for match in re.finditer(equality_pattern, nlq):
        col_name, value = match.groups()
        value = value.strip()
        
        is_numeric_comparison = False
        for op_text, operator in numeric_keywords.items():
            if op_text in value.lower():
                numeric_value_match = re.search(r'\d+', value)
                if numeric_value_match:
                    numeric_value = numeric_value_match.group(0)
                    table_for_col = next((t for t, cols in SCHEMA.items() if col_name.lower() in [c.lower() for c in cols]), None)
                    if table_for_col:
                        actual_col_name = next(c for c in SCHEMA[table_for_col] if c.lower() == col_name.lower())
                        all_conditions.append((table_for_col, actual_col_name, operator, numeric_value))
                        mentioned_columns.add(actual_col_name)
                    is_numeric_comparison = True
                    break
        
        if not is_numeric_comparison:
            table_for_col = next((t for t, cols in SCHEMA.items() if col_name.lower() in [c.lower() for c in cols]), None)
            if table_for_col:
                actual_col_name = next(c for c in SCHEMA[table_for_col] if c.lower() == col_name.lower())
                all_conditions.append((table_for_col, actual_col_name, '=', f"'{value}'"))
                mentioned_columns.add(actual_col_name)

    # --- Determine needed tables from the columns found ---
    needed_tables = set()
    for col in mentioned_columns:
        table_for_col = next((t for t, cols in SCHEMA.items() if col in cols), None)
        if table_for_col:
            needed_tables.add(table_for_col)
    for table, _, _, _ in all_conditions:
        needed_tables.add(table)
    
    # If the user asks for a specific table, ensure it's included
    for table_name in SCHEMA:
        if re.search(rf'\b{table_name}\b', nlq_lower) or re.search(rf'\b{table_name}s\b', nlq_lower):
            needed_tables.add(table_name)
    
    if not needed_tables:
        return ""
    
    # --- Check for single-table query and return early if so ---
    if len(needed_tables) == 1:
        main_table = list(needed_tables)[0]
        main_alias = main_table[:2].lower()
        alias_map = {main_alias: main_table}

        select_cols = []
        if is_count_query:
            if group_by_col:
                if group_by_col.lower() in [c.lower() for c in SCHEMA[main_table]]:
                    actual_group_by_col = next(c for c in SCHEMA[main_table] if c.lower() == group_by_col.lower())
                    select_cols = [f"{main_alias}.{actual_group_by_col}", "COUNT(*)"]
                    group_by_cols.append(f"{main_alias}.{actual_group_by_col}")
                else:
                    select_cols = ["COUNT(*)"]
            else:
                select_cols = ["COUNT(*)"]
        else:
            if agg_func and agg_col:
                table_for_agg = next((t for t, cols in SCHEMA.items() if agg_col in cols), None)
                if table_for_agg:
                    alias = next(a for a, t in alias_map.items() if t == table_for_agg)
                    agg_alias = f"{agg_col}_{agg_func.lower()}"
                    select_cols.append(f"{agg_func}({alias}.{agg_col}) AS {agg_alias}")
            
            if group_by_col:
                actual_group_by_col = next(c for c in SCHEMA[main_table] if c.lower() == group_by_col.lower())
                group_by_cols.append(f"{main_alias}.{actual_group_by_col}")
                if not any(f"{main_alias}.{actual_group_by_col}" in s for s in select_cols):
                    select_cols.append(f"{main_alias}.{actual_group_by_col}")

            for col in mentioned_columns:
                if col == agg_col and agg_func:
                    continue
                table_for_col = next((t for t, cols in SCHEMA.items() if col in cols), None)
                if table_for_col:
                    alias = next(a for a, t in alias_map.items() if t == table_for_col)
                    if f"{alias}.{col}" not in select_cols:
                        select_cols.append(f"{alias}.{col}")
       
        # FIX: Add a fallback to SELECT * if no specific columns are found
        if not select_cols:
            select_cols.append(f"{main_alias}.*")
        
        distinct_keyword = "DISTINCT " if is_unique_query else ""
        select_clause = f"{distinct_keyword}" + ",\n    ".join(select_cols)
        
        where_clauses = []
        having_clauses = []
        for table_name, col_name, operator, value in all_conditions:
            if agg_col and col_name == agg_col:
                having_clauses.append(f"{agg_func}({main_alias}.{col_name}) {operator} {value}")
            else:
                where_clauses.append(f"{main_alias}.{col_name} {operator} {value}")
        
        where_clause = "WHERE " + " AND ".join(where_clauses) if where_clauses else ""
        having_clause = "HAVING " + " AND ".join(having_clauses) if having_clauses else ""
        
        sql = f"SELECT\n    {select_clause}\nFROM {main_table} {main_alias}"
        if where_clause:
            sql += f"\n{where_clause}"
        if group_by_cols:
            sql += f"\nGROUP BY {', '.join(group_by_cols)}"
        if having_clause:
            sql += f"\n{having_clause}"

        if order_by_col:
            actual_order_by_col = next(c for c in SCHEMA[main_table] if c.lower() == order_by_col.lower())
            sql += f"\nORDER BY {main_alias}.{actual_order_by_col} {order_by_dir}"
        elif limit_number and not is_count_query and agg_col:
            sql += f"\nORDER BY {agg_func}({main_alias}.{agg_col}) {order_by_dir if order_by_dir else 'DESC'}"

        if limit_number and not is_count_query:
            sql += f"\nLIMIT {limit_number}"
        return sql
        
    # --- Assign aliases dynamically for multi-table queries ---
    alias_map = {}
    used_aliases = set()
    sorted_tables = sorted(list(needed_tables))
    if not sorted_tables:
        return ""
        
    main_table = sorted_tables[0]
    for table in sorted_tables:
        base_alias = table[:2].lower()
        alias = base_alias
        count = 1
        while alias in used_aliases:
            alias = f"{base_alias}{count}"
            count += 1
        alias_map[alias] = table
        used_aliases.add(alias)

    # --- Generate joins dynamically based on the needed tables ---
    joins_sql = []
    added_tables = {main_table}
    for table in sorted_tables:
        if table in added_tables:
            continue
        path = find_join_path(list(added_tables), table)
        if path:
            joins_sql += generate_joins(path, alias_map, used_aliases, inner_tables=needed_tables)
            added_tables.update([right for _, right, _, _ in path])
    
    from_clause = f"FROM {main_table} {next(a for a, t in alias_map.items() if t == main_table)}\n" + "\n".join(joins_sql)

    # --- Build SELECT clause ---
    select_cols = []
    
    
    if is_count_query:
        if group_by_col:
            table_for_group_by = next((t for t, cols in SCHEMA.items() if group_by_col.lower() in [c.lower() for c in cols]), None)
            if table_for_group_by:
                alias = next(a for a, t in alias_map.items() if t == table_for_group_by)
                actual_group_by_col = next(c for c in SCHEMA[table_for_group_by] if c.lower() == group_by_col.lower())
                select_cols = [f"{alias}.{actual_group_by_col}", "COUNT(*)"]
                group_by_cols.append(f"{alias}.{actual_group_by_col}")
            else:
                select_cols = ["COUNT(*)"]
        else:
            select_cols = ["COUNT(*)"]
    else:
        condition_cols = {c for t, c, o, v in all_conditions}
        if not mentioned_columns or mentioned_columns.issubset(condition_cols):
            if not select_cols:
                for table in sorted_tables:
                    alias = next(a for a, t in alias_map.items() if t == table)
                    for col in SCHEMA[table]:
                        select_cols.append(f"{alias}.{col}")
        else:
            if agg_func and agg_col:
                table_for_agg = next((t for t, cols in SCHEMA.items() if agg_col in cols), None)
                if table_for_agg:
                    alias = next(a for a, t in alias_map.items() if t == table_for_agg)
                    agg_alias = f"{agg_col}_{agg_func.lower()}"
                    select_cols.append(f"{agg_func}({alias}.{agg_col}) AS {agg_alias}")
            
            if group_by_col:
                table_for_group_by = next((t for t, cols in SCHEMA.items() if group_by_col.lower() in [c.lower() for c in cols]), None)
                if table_for_group_by:
                    alias = next(a for a, t in alias_map.items() if t == table_for_group_by)
                    actual_group_by_col = next(c for c in SCHEMA[table_for_group_by] if c.lower() == group_by_col.lower())
                    group_by_cols.append(f"{alias}.{actual_group_by_col}")
                    if not any(f"{alias}.{actual_group_by_col}" in s for s in select_cols):
                        select_cols.append(f"{alias}.{actual_group_by_col}")
            
            for col in mentioned_columns:
                if col == agg_col and agg_func:
                    continue
                table_for_col = next((t for t, cols in SCHEMA.items() if col in cols), None)
                if table_for_col:
                    alias = next(a for a, t in alias_map.items() if t == table_for_col)
                    if f"{alias}.{col}" not in select_cols:
                        select_cols.append(f"{alias}.{col}")
    

    # FIX: Add a fallback to SELECT * if no specific columns are found
    if not select_cols:
        main_alias = next(a for a, t in alias_map.items() if t == main_table)
        select_cols.append(f"{main_alias}.*")

    # Ensure all non-aggregated select columns are in the group by
    if agg_func or is_count_query:
        for col_def in select_cols:
            is_agg = False
            # Fix: Correctly identify COUNT(*) and other aggregates
            if col_def.startswith("COUNT(*)") or any(col_def.startswith(f"{agg_name}(") for agg_name in aggregates.values()):
                is_agg = True
            
            if not is_agg and col_def not in group_by_cols:
                group_by_cols.append(col_def)

    distinct_keyword = "DISTINCT " if is_unique_query else ""
    select_clause = f"{distinct_keyword}" + ",\n    ".join(select_cols)

    # --- Dynamic WHERE and HAVING clause ---
    where_clauses = []
    having_clauses = []
    for table_name, col_name, operator, value in all_conditions:
        alias = next(a for a, t in alias_map.items() if t == table_name)
        if agg_col and col_name == agg_col:
            having_clauses.append(f"{agg_func}({alias}.{col_name}) {operator} {value}")
        else:
            where_clauses.append(f"{alias}.{col_name} {operator} {value}")

    where_clause = "WHERE " + " AND ".join(where_clauses) if where_clauses else ""
    having_clause = "HAVING " + " AND ".join(having_clauses) if having_clauses else ""

    # --- Assemble final SQL ---
    sql = f"SELECT\n    {select_clause}\n{from_clause}"
    if where_clause:
        sql += f"\n{where_clause}"
    if group_by_cols:
        sql += f"\nGROUP BY {', '.join(group_by_cols)}"
    if having_clause:
        sql += f"\n{having_clause}"
    
    if order_by_col:
        table_for_order_by = next((t for t, cols in SCHEMA.items() if order_by_col.lower() in [c.lower() for c in cols]), None)
        if table_for_order_by:
            if agg_func and order_by_col.lower() == agg_col.lower():
                order_by_col_sql = f"{agg_col}_{agg_func.lower()}"
                sql += f"\nORDER BY {order_by_col_sql} {order_by_dir}"
            else:
                alias = next(a for a, t in alias_map.items() if t == table_for_order_by)
                actual_order_by_col = next(c for c in SCHEMA[table_for_order_by] if c.lower() == order_by_col.lower())
                sql += f"\nORDER BY {alias}.{actual_order_by_col} {order_by_dir}"
    elif limit_number and not is_count_query and agg_col:
        order_by_col_sql = f"{agg_col}_{agg_func.lower()}"
        sql += f"\nORDER BY {order_by_col_sql} {order_by_dir if order_by_dir else 'DESC'}"

    if limit_number and not is_count_query:
        sql += f"\nLIMIT {limit_number}"

    return sql

# --- Flask routes ---
@app.route("/")
def index():
    return render_template("index.html")

@app.route("/query", methods=["POST"])
def query():
    try:
        data = request.json
        nlq = data.get("nlq", "")
        sql = build_sql(nlq)
        print("🔎 Generated SQL:", sql)
        result = run_sql(sql)
        return jsonify({"nlq": nlq, "sql": sql, "result": result})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)})

if __name__ == "__main__":
    app.run(debug=True)
